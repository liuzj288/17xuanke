<?php
namespace Home\Model;
use Think\Model\RelationModel;
class MemberModel extends RelationModel {
    // 定义自动验证
    protected $_validate    =   array(
        array('username','require','学生君、あなたの番号を入力してくださいよ(*^__^*) 嘻嘻……'),
        array('passwd','require','身分証明書後6位は(*^__^*) 嘻嘻……'),

        );
    // 定义自动完成
    protected $_auto    =   array(
        array('create_time','time',1,'function'),
        );
 }