<?php
namespace Home\Model;
use Think\Model;
class Course extends Model {
    // 定义自动验证

 }