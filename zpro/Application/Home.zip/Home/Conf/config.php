<?php
return array(
	//'配置项'=>'配置值'
	// 添加数据库配置信息

);