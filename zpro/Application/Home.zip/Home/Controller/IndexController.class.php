<?php
namespace Home\Controller;
use Think\Controller;
class IndexController extends Controller {
    public function _initialize(){
          if (!isset($_SESSION['username'])){
            $this->error('请先登录',U('Member/login'));
        }
      }
    public function index($name = 'thinkphp'){
    	if (!isset($_SESSION['username'])){
    		echo "<script>window.location.href='index.php/home/member/login/';</script>";
    	}else{
    		$this->assign('name',$name);
	    	$data = D('Course');
	    	$result = $data -> select();
	    	$this -> assign('result',$result);

            $select_course = M('member_course') -> where('member_id='.$_SESSION['uid'])->getField('course_id');
           // var_dump($select_course);
            if($select_course){
                $this->assign('no_select',"1"); 
                $this->assign('select_course',$select_course);   
           }else{
                $this->assign('no_select',"-1"); 
              #  $this->assign'select_course','False');
           }
          
	    	$this->display();
    	}
    	
       #echo 'Hello '.$name.' !';
       # $this->show('<style type="text/css">*{ padding: 0; margin: 0; } div{ padding: 4px 48px;} body{ background: #fff; font-family: "微软雅黑"; color: #333;font-size:24px} h1{ font-size: 100px; font-weight: normal; margin-bottom: 12px; } p{ line-height: 1.8em; font-size: 36px } a,a:hover{color:blue;}</style><div style="padding: 24px 48px;"> <h1>:)</h1><p>欢迎使用 <b>ThinkPHP</b>！</p><br/>版本 V{$Think.version}</div><script type="text/javascript" src="http://ad.topthink.com/Public/static/client.js"></script><thinkad id="ad_55e75dfae343f5a1"></thinkad><script type="text/javascript" src="http://tajs.qq.com/stats?sId=9347272" charset="UTF-8"></script>','utf-8');
    }
    public function login(){
    	$this->display();
    }
    public function logincheck(){
    	
    }
    public function logout(){

    }
    
    
    
    
    public function select($id){
        $course = M('Course');

        $where['id'] = $id;

        $result = $course -> where($where) -> find();

    #    var_dump($result);

        if($result['leftnum']>0){

            $s['class'] = '高一2班';
            $s['course_id'] = $id;
            
            $lcasslimit = M('course') -> where('id='.$id)->getField('classlimit');

            $num = M('member_course') ->where($s) -> count();

            if ($num >= $lcasslimit ){
                $this->error('抱歉，你们班级名额已满');
            }


            $select = M('member_course');
           #$test = $select->where('member_id='.session('uid'))->select();
            #print($test);
            if($test){
                $this->error('已经选课了,即将返回选课界面...');
            }else{

                    M('course')->where($where)->setDec('leftnum');
                    M('course')->where($where)->save();


                    $data['member_id'] = session('uid');
                    $data['course_id'] = $result['id'];

                   

                    $data['class'] = M('member') -> where('uid='.$_SESSION['uid'])->getField('class');
                    $select->add($data);
                   
                    $this->success('恭喜你选课成功',U('Index/index'));
            }
          
         }else{
            $this->error('亲，你来晚了，呜哈哈哈哈哈');
         }

    	

    }
    public function unselect($id){
        #退课其实没有什么要求
        #Step1:取消选课表里的选课

        $diselect['memeber_id'] = session('uid');
        $diselect['course_id'] = $id;

        $result = M('member_course')->where($diselect)->delete();

        if($result){
            #Step2:恢复剩余选课数量
            M('course')->where('id='.$id)->setInc('leftnum');
            M('course')->where('id='.$id)->save();
            $this->success('退选成功，请选择其他课程...');
        }else{
            $this->error('退选失败');
        }


    }
    



}