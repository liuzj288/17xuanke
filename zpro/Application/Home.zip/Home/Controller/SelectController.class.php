<?php 
namespace Home\Controller;
use Think\Controller;

class SelectController extends Controller{

	public function index(){

		$data = D('Course') -> select();
		$this -> assign('list',$data);
		$this -> display();
	}
	
    

}

